///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::DefineObjectMaterials() {

}

void SceneManager::SetupSceneLights() {
	// Define light sources here

	// Enable custom lighting
	m_pShaderManager->setBoolValue(g_UseLightingName, true);


	// =========================
	// 0) Main Overhead Light (soft white fill)
	// =========================
	m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(0.0f, 8.0f, 0.0f));
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.12f, 0.12f, 0.12f));
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(0.70f, 0.70f, 0.70f));
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(1.00f, 1.00f, 1.00f));
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 8.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.05f);

	// =========================
	// 1) Left Side Fill Light � Strong Blue
	// =========================
	m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(-6.0f, 3.0f, 3.0f));
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.05f, 0.08f, 0.20f)); // dark blue ambient
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(0.10f, 0.40f, 1.00f)); // bright blue diffuse
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(0.30f, 0.60f, 1.00f)); // blue highlights
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 8.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.15f);

	// =========================
	// 2) Right Side Fill Light (neutral)
	// =========================
	m_pShaderManager->setVec3Value("lightSources[2].position", glm::vec3(6.0f, 3.0f, 3.0f));
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", glm::vec3(0.05f, 0.05f, 0.05f));
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", glm::vec3(0.40f, 0.40f, 0.40f));
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", glm::vec3(0.50f, 0.50f, 0.50f));
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 8.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.15f);

	// =========================
	// 3) Lamp Bulb Light (warm yellow glow)
	// =========================
	m_pShaderManager->setVec3Value("lightSources[3].position", glm::vec3(1.8f, 3.4f, -3.6f));
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", glm::vec3(0.20f, 0.18f, 0.10f));
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", glm::vec3(1.00f, 0.90f, 0.60f));
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", glm::vec3(1.00f, 0.90f, 0.70f));
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 16.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.60f);

}

void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;// variable to store success/failure of texture loading


	// Load block wall texture and assign it a label
	bReturn = CreateGLTexture("textures/BLOCK.jpg", "block");

	// Load fabric texture and assign it a label
	bReturn = CreateGLTexture("textures/FABRIC.jpg", "fabric");

	// Load tile floor texture and assign it a label
	bReturn = CreateGLTexture("textures/TILE.jpg", "tile");

	// Load light wood texture and assign it a label
	bReturn = CreateGLTexture("textures/WOOD.jpg", "wood");

	// Load dark wood texture and assign it a label
	bReturn = CreateGLTexture("textures/DARKWOOD.jpg", "darkwood");
	// Load brick texture and assing it a label

	bReturn = CreateGLTexture("textures/BRICK.jpg", "brick");
	// Bind all the loaded textures for use in rendering

	// Load carpet texture and assign it a label
	bReturn = CreateGLTexture("textures/CARPET.jpg", "carpet");

	// Load gray fabric texture and assign it a label
	bReturn = CreateGLTexture("textures/GRAYFABRIC.jpg", "grayfabric");

	// Load marble texture and assign it a label
	bReturn = CreateGLTexture("textures/MARBLE.jpg", "marble");


	BindGLTextures();
}



void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	LoadSceneTextures();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();     
	m_basicMeshes->LoadConeMesh(); 
	m_basicMeshes->LoadBoxMesh();
	// Call lights + materials setup
	DefineObjectMaterials();
	SetupSceneLights();
	
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	// Make the tile glossier
	m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.20f)); // subtle
	m_pShaderManager->setFloatValue("material.shininess", 1.5f);               // mild highlight        

	//SetShaderColor(1, 1, 1, 1);
	
	// I commented out the set shade color and changed the floos to a texture 

	//TEXTURE
	SetShaderTexture("marble");
	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();


	/************************************************************/
/*** BACK WALL � BOX MESH                                 ***/
/*** This wall defines the background boundary of the     ***/
/*** 3D scene and helps frame the space where objects     ***/
/*** like the shelf and lamp will be placed. It simulates ***/
/*** a real wall in a room environment.                   ***/
/************************************************************/

// Set the scale of the wall (width, height, depth)
// This wall is wide and tall, but shallow in depth
	scaleXYZ = glm::vec3(40.0f, 15.0f, 0.5f);

	// No rotation needed since the wall faces forward
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the wall upright behind the white base (floor)
	// The Y-value raises it up, and the negative Z pushes it behind the scene
	positionXYZ = glm::vec3(0.0f, 7.5f, -5.5f);

	// Apply the transformations to the wall shape
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set the wall color using an RGB value from the user's reference image
	// This soft blue gives the wall a calm, room-like appearance
	//SetShaderColor(0.537f, 0.675f, 0.784f, 1.0f);



	// TEXTURE
	SetShaderTexture("brick");//Changed the wall background into a block type texture

	// Draw the box mesh using the shape, color, and transformation values
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
	/******************************/
/*** LAMP BASE � CYLINDER  ***/
/******************************/
	scaleXYZ = glm::vec3(1.0f, 0.2f, 1.0f);     // scale: wide and flat
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(1.8f, 1.30f, -3.796f);


	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.55f, 0.27f, 0.07f, 1.0f);     // brown (wood tone)
	
	//TEXTURE
	// Commented out the shade color and replaced it with a dark wood texture
	SetShaderTexture("darkwood");

	m_basicMeshes->DrawCylinderMesh();

	/****************************/
	/*** LAMP POLE � CYLINDER ***/
	/****************************/
	// Set the transformations for the lamp pole (cylinder)
	scaleXYZ = glm::vec3(0.15f, 1.5f, 0.15f);       // scale: tall and narrow
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(1.8f, 1.3f, -3.796f);




	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.55f, 0.27f, 0.07f, 1.0f);      // same brown
	
	// TEXTURE
	// Commented out the shade color and replaced it with a dark wood texture
	SetShaderTexture("darkwood");
	
	m_basicMeshes->DrawCylinderMesh();


	/******************************/
/*** LAMP SHADE � BOX       ***/
/******************************/
	scaleXYZ = glm::vec3(1.5f, 1.3f, 1.5f); // dimensions for the lamp shade
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(1.8f, 3.25f, -3.796f);


	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(1.0f, 0.95f, 0.8f, 1.0f); // light yellow
	
	//TEXTURE
	// Commented out the shade color and replaced it with a fabric texture
	SetShaderTexture("grayfabric");
	
	m_basicMeshes->DrawBoxMesh();  // BOX Shaped lamp shade
	/************************************************************/
/*** IKEA WALL SHELF - BACK PANEL + SHELVES + SHOE BOXES  ***/
/************************************************************/
	{
		// Wall reference
		const float wallCenterZ = -5.5f;
		const float wallDepth = 0.5f;
		const float wallFrontZ = wallCenterZ + wallDepth * 0.5f;

		// Dimensions
		const int   kShelves = 7;
		const float panelW = 2.6f;
		const float panelH = 13.0f;
		const float panelT = 0.15f;

		const float shelfW = panelW;
		const float shelfD = 2.6f;
		const float shelfT = 0.20f;
		const float gap = 1.55f;
		const float bottomOff = 0.40f;

		// Placement
		const float floorClearance = 0.60f;
		const float panelCenterZ = wallFrontZ + panelT * 0.5f + 0.002f;
		const glm::vec3 panelBottomCenter = glm::vec3(1.8f, floorClearance, panelCenterZ);

		// Matte white material
		SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
		m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.05f));
		m_pShaderManager->setFloatValue("material.shininess", 0.5f);

		// Common transform vars
		glm::vec3 scaleXYZ;
		glm::vec3 positionXYZ;
		float XrotationDegrees = 0.0f;
		float YrotationDegrees = 0.0f;
		float ZrotationDegrees = 0.0f;

		/******************************/
		/*** BACK PANEL - BOX MESH  ***/
		/******************************/
		scaleXYZ = glm::vec3(panelW, panelH, panelT);
		positionXYZ = panelBottomCenter + glm::vec3(0.0f, panelH * 0.5f, 0.0f);

		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		m_basicMeshes->DrawBoxMesh();

		/******************************/
		/*** SHELVES - BOX MESHES   ***/
		/******************************/
		const float shelfCenterZ = panelCenterZ + (panelT * 0.5f) + (shelfD * 0.5f) + 0.002f;

		scaleXYZ = glm::vec3(shelfW, shelfT, shelfD);

		float y = panelBottomCenter.y + bottomOff + shelfT * 0.5f;
		for (int i = 0; i < kShelves; ++i) {

			// Skip the shelf we want to remove
			if (i == 1) { // 0 = bottom shelf, 1 = second from bottom
				if (i < kShelves - 1) {
					y += shelfT + gap; // still move up for the next shelf
				}
				continue;
			}

			positionXYZ = glm::vec3(panelBottomCenter.x, y, shelfCenterZ);

			SetTransformations(
				scaleXYZ,
				XrotationDegrees,
				YrotationDegrees,
				ZrotationDegrees,
				positionXYZ);

			m_basicMeshes->DrawBoxMesh();

			if (i < kShelves - 1) {
				y += shelfT + gap;
			}
		}


		/************************************************************/
		/*** SHOE BOX #1 - CARDBOARD BOX on UPPER MIDDLE SHELF    ***/
		/************************************************************/
		{
			const int   shelfIndex = 5; // one below top
			const float shelfStartY = panelBottomCenter.y + bottomOff + shelfT * 0.5f;
			const float yShelfCenter = shelfStartY + shelfIndex * (shelfT + gap);
			const float yTopOfShelf = yShelfCenter + shelfT * 0.5f;

			const float boxW = shelfW * 0.95f;
			const float boxD = shelfD * 0.85f;
			const float boxH = 0.75f;
			const float lidH = 0.12f;

			// Base
			scaleXYZ = glm::vec3(boxW, boxH, boxD);
			positionXYZ = glm::vec3(panelBottomCenter.x, yTopOfShelf + boxH * 0.5f, shelfCenterZ);

			SetShaderColor(0.82f, 0.71f, 0.55f, 1.0f);
			m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.03f));
			m_pShaderManager->setFloatValue("material.shininess", 0.4f);

			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			// Lid
			scaleXYZ = glm::vec3(boxW * 1.01f, lidH, boxD * 1.01f);
			positionXYZ = glm::vec3(panelBottomCenter.x, yTopOfShelf + boxH + lidH * 0.5f, shelfCenterZ);

			SetShaderColor(0.74f, 0.63f, 0.48f, 1.0f);
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();
		}

		/************************************************************/
        /*** SHOE BOX #2 - BLUE BOX on TOP SHELF                  ***/
        /************************************************************/
		{
			const int   shelfIndex = 6; // top
			const float shelfStartY = panelBottomCenter.y + bottomOff + shelfT * 0.5f;
			const float yShelfCenter = shelfStartY + shelfIndex * (shelfT + gap);
			const float yTopOfShelf = yShelfCenter + shelfT * 0.5f;

			const float boxW = shelfW * 0.95f;   // bigger width
			const float boxD = shelfD * 0.85f;   // bigger depth
			const float boxH = 0.75f;            // taller
			const float lidH = 0.12f;            // taller lid

			// Entire box (blue)
			scaleXYZ = glm::vec3(boxW, boxH, boxD);
			positionXYZ = glm::vec3(panelBottomCenter.x, yTopOfShelf + boxH * 0.5f, shelfCenterZ);

			SetShaderColor(0.14f, 0.42f, 0.86f, 1.0f); // blue
			m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.04f));
			m_pShaderManager->setFloatValue("material.shininess", 0.5f);

			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();

			// Lid (same blue, just slightly larger in width/depth)
			scaleXYZ = glm::vec3(boxW * 1.01f, lidH, boxD * 1.01f);
			positionXYZ = glm::vec3(panelBottomCenter.x, yTopOfShelf + boxH + lidH * 0.5f, shelfCenterZ);

			SetShaderColor(0.14f, 0.42f, 0.86f, 1.0f); // blue lid
			SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
			m_basicMeshes->DrawBoxMesh();
		}

	}
	/**************** end IKEA WALL SHELF (with shoeboxes) ****************/
                /******** WARDROBE ********/
{
	// Wall reference
	const float wallCenterZ = -5.5f;
	const float wallDepth = 0.5f;
	const float wallFrontZ = wallCenterZ + wallDepth * 0.5f;

	// Much wider, same tall height as shoe shelf
	glm::vec3 scaleXYZ = glm::vec3(6.0f, 13.0f, 2.0f);

	// Position: moved left, against wall, sitting on floor
	glm::vec3 positionXYZ = glm::vec3(-6.0f, scaleXYZ.y * 0.5f, wallFrontZ + scaleXYZ.z * 0.5f + 0.01f);

	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;

	// Dark wood texture or color
	SetShaderTexture("darkwood");
	// SetShaderColor(0.15f, 0.07f, 0.03f, 1.0f); // if no texture

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawBoxMesh();
}
/***************************************************************************************/

/************************************************************/
/*** SIDE WALLS � BOX MESHES (Extended)                   ***/
/*** Flush with the back wall and extend toward camera.   ***/
/************************************************************/

// Back wall reference (must match your back-wall values)
const glm::vec3 backWallScale = glm::vec3(40.0f, 15.0f, 0.5f);
const glm::vec3 backWallPos = glm::vec3(0.0f, 7.5f, -5.5f);

// Front face (Z) of the back wall
const float backWallFrontZ = backWallPos.z + backWallScale.z * 0.5f;

// Side wall dimensions
const float sideThickness = 0.5f;            
const float sideHeight = backWallScale.y; 
const float sideDepth = 14.0f;           

// Reusable transforms
XrotationDegrees = 0.0f;
YrotationDegrees = 0.0f;
ZrotationDegrees = 0.0f;

/******************************/
/*** LEFT SIDE WALL         ***/
/******************************/
scaleXYZ = glm::vec3(sideThickness, sideHeight, sideDepth);
positionXYZ = glm::vec3(
	backWallPos.x - backWallScale.x * 0.5f + sideThickness * 0.5f,  
	sideHeight * 0.5f,                                              
	backWallFrontZ + sideDepth * 0.5f                               // start at back wall
);

SetTransformations(
	scaleXYZ,
	XrotationDegrees,
	YrotationDegrees,
	ZrotationDegrees,
	positionXYZ);

SetShaderTexture("brick");
m_basicMeshes->DrawBoxMesh();

/******************************/
/*** RIGHT SIDE WALL        ***/
/******************************/
scaleXYZ = glm::vec3(sideThickness, sideHeight, sideDepth);
positionXYZ = glm::vec3(
	backWallPos.x + backWallScale.x * 0.5f - sideThickness * 0.5f,  
	sideHeight * 0.5f,                                              
	backWallFrontZ + sideDepth * 0.5f
);

SetTransformations(
	scaleXYZ,
	XrotationDegrees,
	YrotationDegrees,
	ZrotationDegrees,
	positionXYZ);

SetShaderTexture("brick");
m_basicMeshes->DrawBoxMesh();

/************************************************************/
/*** SECTIONAL COUCH � BOX MESHES                         ***/
/*** This creates an L-shaped couch tucked into the        ***/
/*** back/right corner. I moved it slightly so it doesn�t   ***/
/*** overlap the shoe shelf. The couch uses the "fabric"    ***/
/*** texture for upholstery.                               ***/
/************************************************************/
{
	/******************************/
	/*** ROOM / WALL REFERENCES ***/
	/******************************/
	// These match the back wall dimensions from earlier
	const float backWallCenterZ = -5.5f;
	const float backWallDepth = 0.5f;
	const float backWallFrontZ = backWallCenterZ + backWallDepth * 0.5f; // front face

	// Calculate the right inner edge of the room
	const float roomHalfWidth = 40.0f * 0.5f;   // half of back wall width
	const float sideThickness = 0.5f;           // same side wall thickness as before
	const float roomRightInnerX = +roomHalfWidth - sideThickness;

	/******************************/
	/*** SHOE SHELF REFERENCES  ***/
	/******************************/
	// Position and size of the shoe shelf to avoid clipping
	const float shelfCenterX = 1.8f;
	const float panelW = 2.6f;                           // width of shelf�s back panel
	const float shelfRightX = shelfCenterX + panelW * 0.5f;   // rightmost edge of shelf

	/******************************/
	/*** SMALL GAPS / OFFSETS   ***/
	/******************************/
	const float gap = 0.60f; // space between couch and shelf
	const float zEps = 0.02f; // push slightly forward from wall to avoid z-fighting
	const float xEps = 0.20f; // small gap from right wall
	const float yEps = 0.05f; // lift slightly off the floor

	/******************************/
	/*** COUCH DIMENSIONS       ***/
	/******************************/
	const float seatW = 5.5f;  // width of each seat section
	const float seatH = 2.5f;  // seat height
	const float seatD = 3.5f;  // depth for standard seats
	const float chaiseD = 7.0f;  // depth for chaise section

	// Positions for seat height and depth
	const float ySeat = seatH * 0.5f + yEps;
	const float zSeat = backWallFrontZ + seatD * 0.5f + zEps;
	const float zChaise = backWallFrontZ + chaiseD * 0.5f + zEps;

	// Start by placing seats snug to the right wall
	float xRightSeat = (roomRightInnerX - xEps) - seatW * 0.5f;
	float xLeftSeat = xRightSeat - seatW;

	// Make sure the left seat clears the shoe shelf
	const float minLeftSeatCenterX = (shelfRightX + gap) + seatW * 0.5f;
	if (xLeftSeat < minLeftSeatCenterX) {
		const float delta = minLeftSeatCenterX - xLeftSeat;
		xLeftSeat += delta;
		xRightSeat += delta;
	}

	/******************************/
	/*** COMMON ROTATIONS       ***/
	/******************************/
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Upholstery texture
	SetShaderTexture("fabric");

	/******************************/
	/*** LEFT BACK SEAT         ***/
	/******************************/
	scaleXYZ = glm::vec3(seatW, seatH, seatD);
	positionXYZ = glm::vec3(xLeftSeat, ySeat, zSeat);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	/******************************/
	/*** RIGHT BACK SEAT        ***/
	/******************************/
	scaleXYZ = glm::vec3(seatW, seatH, seatD);
	positionXYZ = glm::vec3(xRightSeat, ySeat, zSeat);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	/******************************/
	/*** CHAISE SECTION         ***/
	/******************************/
	// Extends toward the camera
	scaleXYZ = glm::vec3(seatW, seatH, chaiseD);
	positionXYZ = glm::vec3(xRightSeat, ySeat, zChaise);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	/******************************/
	/*** BACKRESTS              ***/
	/******************************/
	const float backH = 2.2f;  // height of backrest
	const float backT = 0.6f;  // thickness of backrest
	const float yBack = seatH + backH * 0.5f + yEps;
	const float zBack = backWallFrontZ + backT * 0.5f + zEps;

	// Behind left seat
	scaleXYZ = glm::vec3(seatW, backH, backT);
	positionXYZ = glm::vec3(xLeftSeat, yBack, zBack);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	// Behind right seat
	scaleXYZ = glm::vec3(seatW, backH, backT);
	positionXYZ = glm::vec3(xRightSeat, yBack, zBack);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	/******************************/
	/*** RIGHT ARMREST          ***/
	/******************************/
	const float armW = 0.8f;
	const float armH = seatH + 1.1f;
	const float armD = chaiseD;
	const float yArm = armH * 0.5f + yEps;

	scaleXYZ = glm::vec3(armW, armH, armD);
	positionXYZ = glm::vec3(roomRightInnerX - 0.10f - armW * 0.5f, yArm, zChaise);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawBoxMesh();
}
/**************** end SECTIONAL COUCH ****************/

/************************************************************/
/*** SECOND WARDROBE � LIGHT WOOD                         ***/
/*** Positioned next to the existing brown wardrobe to    ***/
/*** add more furniture variety. Uses same size and       ***/
/************************************************************/
{
	// Back wall reference (must match your wall values)
	const float backWallCenterZ = -5.5f;   // wall's center point along Z-axis
	const float backWallDepth = 0.5f;    // thickness of the wall
	const float backWallFrontZ = backWallCenterZ + backWallDepth * 0.5f;

	// Wardrobe dimensions (same as first wardrobe)
	glm::vec3 scaleXYZ = glm::vec3(6.0f, 13.0f, 2.0f);

	// Position wardrobe to the LEFT of the brown wardrobe
	// First wardrobe was centered at X = -6.0f, so we move left by its width plus a small gap
	const float gapX = 0.2f;
	glm::vec3 positionXYZ = glm::vec3(-6.0f - (scaleXYZ.x + gapX),  // X position
		scaleXYZ.y * 0.5f,            // Y position (sits on floor)
		backWallFrontZ + scaleXYZ.z * 0.5f + 0.01f); // Z position

	// Rotation angles (no rotation for this wardrobe)
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;

	// Apply lighter wood texture for visual contrast
	SetShaderTexture("wood"); // Uses existing wood texture loaded in setup

	// Apply transformations and draw the wardrobe box
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawBoxMesh();
}
/************************************************************/
/*** CYLINDER COFFEE TABLE                                 ***/
/*** Built from 3 cylinders: base disk, pedestal, tabletop.***/
/*** Textures: dark wood base/pedestal, marble tabletop.   ***/
/************************************************************/
{
	// I�m placing the table in the side of the couch.
	// If it�s too close/far, nudge positionXYZ.z by �0.2f later.
	const float tableX = 15.8f;   // left/right in room
	const float tableZ = 5.75f;  // 

	// Reusable rotation (table stands upright)
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;

	/******************************/
	/*** 1) BASE DISK (cylinder) ***/
	/******************************/
	// Short, wide disk to ground the table
	glm::vec3 scaleXYZ = glm::vec3(0.90f, 0.20f, 0.90f);    // radiusX/Z, heightY
	glm::vec3 positionXYZ = glm::vec3(tableX, scaleXYZ.y * 0.5f, tableZ); // sits on floor

	SetShaderTexture("darkwood"); // wood base
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	/******************************/
	/*** 2) PEDESTAL (cylinder)  ***/
	/******************************/
	// Tall, slimmer center column
	scaleXYZ = glm::vec3(0.35f, 1.25f, 0.35f);
	positionXYZ = glm::vec3(tableX, scaleXYZ.y * 0.25f, tableZ); // sits on top of floor

	SetShaderTexture("darkwood"); // same wood for the column
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	/******************************/
	/*** 3) TABLETOP (cylinder)  ***/
	/******************************/
	// Wider, thin round top
	const float pedestalTopY = 1.5f; // height of the pedestal (same as scaleXYZ.y above)
	scaleXYZ = glm::vec3(2.20f, 0.150f, 2.20f);  // big radius, thin height
	positionXYZ = glm::vec3(tableX, pedestalTopY + scaleXYZ.y * 0.5f, tableZ);

	SetShaderTexture("marble"); // use your MARBLE.jpg for a nice top
	// If you prefer wood instead: SetShaderTexture("wood");

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();
}
/**************** end CYLINDER COFFEE TABLE ****************/







}







